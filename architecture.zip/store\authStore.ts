import { create } from "zustand";

type AuthState = {
  token: string | null;
  isAuthenticated: boolean;
  setToken: (token: string | null) => void;
  logout: () => void;
};

export const useAuthStore = create<AuthState>((set) => ({
  token: localStorage.getItem("ragavi_token"),
  isAuthenticated: Boolean(localStorage.getItem("ragavi_token")),
  setToken: (token) => {
    if (token) {
      localStorage.setItem("ragavi_token", token);
    } else {
      localStorage.removeItem("ragavi_token");
    }
    set({ token, isAuthenticated: Boolean(token) });
  },
  logout: () => {
    localStorage.removeItem("ragavi_token");
    set({ token: null, isAuthenticated: false });
  },
}));
