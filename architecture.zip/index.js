import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import OpenAI from "openai";
import db from "./db.js";

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || "supersecuresecret";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

app.use(cors({ origin: "http://localhost:5173" }));
app.use(express.json());

function createToken(user) {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, {
    expiresIn: "8h",
  });
}

async function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Missing token" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (error) {
    res.status(401).json({ message: "Invalid token" });
  }
}

app.post("/api/auth/register", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  const passwordHash = await bcrypt.hash(password, 10);

  try {
    const result = await db.run(
      "INSERT INTO users (email, passwordHash) VALUES (?, ?)",
      email,
      passwordHash
    );

    const user = { id: result.lastID, email, role: "teacher" };
    const token = createToken(user);
    res.json({ token });
  } catch (error) {
  console.error("REGISTER ERROR:", error);
  res.status(500).json({
    message: error.message,
    error,
  });
}
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await db.get("SELECT * FROM users WHERE email = ?", email);

  if (!user) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const isValid = await bcrypt.compare(password, user.passwordHash);
  if (!isValid) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const token = createToken(user);
  res.json({ token });
});

app.get("/api/settings", authenticate, async (req, res) => {
  const settings = await db.get("SELECT * FROM school_settings WHERE id = 1");
  res.json(settings);
});

app.put("/api/settings", authenticate, async (req, res) => {
  const { schoolName, startTime, endTime, periodsPerDay, workingDays, lunchDuration } = req.body;
  await db.run(
    "UPDATE school_settings SET schoolName = ?, startTime = ?, endTime = ?, periodsPerDay = ?, workingDays = ?, lunchDuration = ? WHERE id = 1",
    schoolName,
    startTime,
    endTime,
    periodsPerDay,
    workingDays,
    lunchDuration
  );
  const settings = await db.get("SELECT * FROM school_settings WHERE id = 1");
  res.json(settings);
});

app.get("/api/teachers", authenticate, async (req, res) => {
  const teachers = await db.all("SELECT * FROM teachers");
  res.json(teachers);
});

app.post("/api/teachers", authenticate, async (req, res) => {
  const { id, code, name, subject, workload } = req.body;
  await db.run("INSERT INTO teachers (id, code, name, subject, workload) VALUES (?, ?, ?, ?, ?)", id, code, name, subject, workload);
  const teachers = await db.all("SELECT * FROM teachers");
  res.json(teachers);
});

app.delete("/api/teachers/:id", authenticate, async (req, res) => {
  await db.run("DELETE FROM teachers WHERE id = ?", req.params.id);
  // Nullify teacherId in allocations that referenced this teacher
  await db.run("UPDATE allocations SET teacherId = NULL WHERE teacherId = ?", req.params.id);
  res.json({ success: true });
});

app.get("/api/subjects", authenticate, async (req, res) => {
  const subjects = await db.all("SELECT * FROM subjects");
  res.json(subjects);
});

app.post("/api/subjects", authenticate, async (req, res) => {
  const { id, name, periodsPerWeek } = req.body;
  await db.run("INSERT INTO subjects (id, name, periodsPerWeek) VALUES (?, ?, ?)", id, name, periodsPerWeek);
  const subjects = await db.all("SELECT * FROM subjects");
  res.json(subjects);
});

app.delete("/api/subjects/:id", authenticate, async (req, res) => {
  await db.run("DELETE FROM subjects WHERE id = ?", req.params.id);
  // Remove allocations referencing this subject
  await db.run("DELETE FROM allocations WHERE subjectId = ?", req.params.id);
  res.json({ success: true });
});

app.get("/api/classes", authenticate, async (req, res) => {
  const classes = await db.all("SELECT * FROM classes");
  res.json(classes);
});

app.post("/api/classes", authenticate, async (req, res) => {
  const { id, className, section } = req.body;
  await db.run("INSERT INTO classes (id, className, section) VALUES (?, ?, ?)", id, className, section);
  const classes = await db.all("SELECT * FROM classes");
  res.json(classes);
});

app.delete("/api/classes/:id", authenticate, async (req, res) => {
  await db.run("DELETE FROM classes WHERE id = ?", req.params.id);
  // Remove allocations referencing this class
  await db.run("DELETE FROM allocations WHERE classId = ?", req.params.id);
  res.json({ success: true });
});

app.get("/api/allocations", authenticate, async (req, res) => {
  const allocations = await db.all("SELECT * FROM allocations");
  res.json(allocations);
});

app.post("/api/allocations", authenticate, async (req, res) => {
  const { id, classId, subjectId, teacherId, periods } = req.body;
  await db.run(
    "INSERT INTO allocations (id, classId, subjectId, teacherId, periods) VALUES (?, ?, ?, ?, ?)",
    id,
    classId,
    subjectId,
    teacherId || null,
    periods
  );
  const allocations = await db.all("SELECT * FROM allocations");
  res.json(allocations);
});

app.delete("/api/allocations/:id", authenticate, async (req, res) => {
  await db.run("DELETE FROM allocations WHERE id = ?", req.params.id);
  res.json({ success: true });
});

app.post("/api/ai/timetable", authenticate, async (req, res) => {
  const { allocations, teachers, subjects, classes, settings } = req.body;

  if (!OPENAI_API_KEY) {
    return res.status(500).json({ message: "OpenAI API key is not configured." });
  }

  const prompt = `You are an AI assistant building a Tamil Nadu State Board school timetable. Use the following data:
- School settings: ${JSON.stringify(settings)}
- Teachers: ${JSON.stringify(teachers)}
- Subjects: ${JSON.stringify(subjects)}
- Classes: ${JSON.stringify(classes)}
- Allocations: ${JSON.stringify(allocations)}

Note: The allocations reference classes by 'classId', subjects by 'subjectId', and teachers by 'teacherId'.
Generate a creative weekly timetable in JSON format. Use days Monday to Friday, numbered periods, and assign teacher subjects to class periods. Return an object with days and period rows. In the output timetable, resolve the className and subject name from their IDs.
`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are a helpful timetable planning assistant." },
        { role: "user", content: prompt },
      ],
      temperature: 0.8,
      max_tokens: 1000,
    });

    const assistantText = completion.choices?.[0]?.message?.content || "";
    let timetable = {};

    try {
      timetable = JSON.parse(assistantText);
    } catch (error) {
      return res.status(500).json({ message: "AI returned invalid JSON.", raw: assistantText });
    }

    res.json({ timetable });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Unable to generate AI timetable." });
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
